﻿namespace EcommerceCheckoutAPI.Services
{
    public interface ICatalogService
    {
        public double GetCheckoutPrice(List<string> watches);
    }
}
