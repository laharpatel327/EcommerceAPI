﻿using EcommerceCheckoutAPI.Models;

namespace EcommerceCheckoutAPI.Repositories
{
    public interface ICatalogRepository
    {
        public List<WatchCatalogue> GetCatalogRepository();
    }
}
